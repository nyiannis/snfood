<?php
/**
 * Template part for display languages
 * @package Razzi
 */

?>
<div class="header-languages">
	<?php \Razzi\Helper::language_switcher(); ?>
</div><!-- .header-languages -->
