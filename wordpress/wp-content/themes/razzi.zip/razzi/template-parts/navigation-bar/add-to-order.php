<?php
/**
 * Template file for displaying filter mobile
 *
 * @package Razzi
 */

?>

<a href="#" class="button razzi-button rz-navigation-bar__btn-place-order"><?php echo esc_html__( 'Place order', 'razzi' ) ?></a>