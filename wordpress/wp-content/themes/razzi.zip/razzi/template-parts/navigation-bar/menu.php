<?php
/**
 * Template file for displaying menu mobile
 *
 * @package Razzi
 */
?>

<a href="#" class="rz-navigation-bar_icon menu-icon" data-toggle="modal" data-target="mobile-category-menu-modal">
	<?php echo \Razzi\Icon::get_svg( 'hamburger' ); ?>
</a>
